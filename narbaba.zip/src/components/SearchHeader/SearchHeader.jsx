import React from 'react'
// Styles
import {Wrapper} from "./SearchHeader.styles"
const SearchHeader = () => {
  return (
    <Wrapper>SearchHeader</Wrapper>
  )
}

export default SearchHeader