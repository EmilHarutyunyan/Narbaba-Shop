import React from 'react'

const Error = ({msg=""}) => {
  return (
    <div>{msg}</div>
  )
}

export default Error