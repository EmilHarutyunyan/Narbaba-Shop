import ProfilePassword from './ProfilePassword.lazy';
export default ProfilePassword;