import ProfileAccount from './ProfileAccount.lazy';
export default ProfileAccount;