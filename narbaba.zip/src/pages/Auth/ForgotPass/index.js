import ForgotPass from "./ForgotPass.jsx";
export default ForgotPass;
