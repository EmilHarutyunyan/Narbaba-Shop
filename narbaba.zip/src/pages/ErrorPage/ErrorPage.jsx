import React from 'react'
// Styles
import {Wrapper} from "./ErrorPage.styles"
const ErrorPage = () => {
  return (
    <Wrapper>ErrorPage</Wrapper>
  )
}

export default ErrorPage