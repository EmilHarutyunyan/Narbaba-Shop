import ErrorPage from './ErrorPage.lazy';
export default ErrorPage;