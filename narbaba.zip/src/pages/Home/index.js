import Home from './Home.lazy.jsx';
export default Home;