import React from 'react'
// Styles
import {Wrapper} from "./Home.styles"
const Home = () => {
  return (
    <Wrapper>Home</Wrapper>
  )
}

export default Home