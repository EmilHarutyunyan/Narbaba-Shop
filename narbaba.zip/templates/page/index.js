import TemplateName from './TemplateName.lazy';
export default TemplateName;