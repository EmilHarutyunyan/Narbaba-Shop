import React from 'react'
// Styles
import {Wrapper} from "./TemplateName.styles"
const TemplateName = () => {
  return (
    <Wrapper>TemplateName</Wrapper>
  )
}

export default TemplateName