import TemplateName from './TemplateName';
export default TemplateName;